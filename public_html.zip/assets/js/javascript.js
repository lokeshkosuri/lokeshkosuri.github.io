$('.testimonials-slider').bxSlider({
  slideWidth: 800,
  minSlides: 1,
  maxSlides: 1,
  slideMargin: 32,
  auto: true,
  autoControls: true
});
